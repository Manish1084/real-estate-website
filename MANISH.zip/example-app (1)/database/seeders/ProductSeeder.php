<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([

            [
    		'name' =>'MAHALAXMI APARTMENT',
    	    'price' =>' 60Lac ',
    	    'description' =>'Bedrooms 5 Bathrooms5 Super area 3220 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'INDORE',
            'gallery' => 'https://teja12.kuikr.com/is/a/f/800x600/gallery_images/original/5809a10324d3a.jpg',

            ],

             [
            'name' =>'RAJ BUILDING',
            'price' =>' 55Lac ',
            'description' =>'Bedrooms 2 Bathrooms 2 Super area 2000 sqfLift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless.t',
            'category' =>'BHOPAL',
            'gallery' => 'https://teja12.kuikr.com/is/a/f/800x600/gallery_images/original/5809a10324d3a.jpg',

            ], [
            'name' =>'OMNI VIHAR',
            'price' =>' 70Lac ',
            'description' =>'Bedrooms 5 Bathrooms 3 Super area 5220 sqfLift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless.t',
            'category' =>'MUMBAI',
            'gallery' => 'https://i.pinimg.com/originals/e6/56/84/e65684e8d594018bb5e52dfb641082f6.jpg',

            ],



 [
            'name' =>'KARUNA SAGAR',
            'price' =>' 60Lac ',
            'description' =>'3 Bedrooms 2 Bathrooms Super area 2020 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'PUNE',
            'gallery' => 'https://photos.zillowstatic.com/fp/994ab74dbbc7c15881d74488169fafc3-p_e.jpg',

            ], [
            'name' =>'MAHAVIR COLONY',
            'price' =>' 12Cr ',
            'description' =>'9 Bedrooms 5 Bathrooms5 Super area 8020 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'DELHI',
            'gallery' => 'https://rentpath-res.cloudinary.com/w_336,h_280,t_rp,cs_tinysrgb,fl_force_strip,c_fill/e_unsharp_mask:50,q_auto/900d4a171865a43d5d8a77a4731aade3',

            ], [
            'name' =>'SAI COLONY',
            'price' =>'50Laac ',
            'description' =>' 2Bedrooms  Bathrooms 2 Super area 3500 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'INDORE',
            'gallery' => 'https://i.pinimg.com/originals/e6/56/84/e65684e8d594018bb5e52dfb641082f6.jpg',

            ],
            


            [
            'name' =>'SWARN VIHAR',
            'price' =>' 2Cr ',
            'description' =>'Bedrooms 5 Bathrooms3 Super area 7220 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'UJJAIN',
            'gallery' => 'https://is1-2.housingcdn.com/4f2250e8/d385768b62d6a31a07bdab555cf82500/v0/fs/jagadhabi_mithila-jayanagar-bengaluru-jagadhabi_constructions.jpeg',

            ],
            [
            'name' =>'MOON COLONY',
            'price' =>'3Cr ',
            'description' =>'Bedrooms 5 Bathrooms 3 Super area 5220 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'RAJGARH',
            'gallery' => 'https://teja8.kuikr.com//r1/20190529/ak_668_1700390711-1559105581_700x700.png',

            ],
            [
            'name' =>'ANTILIA',
            'price' =>' 30Lac ',
            'description' =>'Bedrooms 5 Bathrooms5 Super area 2220 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'MANDSAUR',
            'gallery' => 'https://i.pinimg.com/originals/e6/56/84/e65684e8d594018bb5e52dfb641082f6.jpg',

            ],
            



            [
            'name' =>'ANTILIA',
            'price' =>' 60Lac ',
            'description' =>'Bedrooms 5 Bathrooms5 Super area 5020 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'DARJLING',
            'gallery' => 'https://i.pinimg.com/originals/87/4b/11/874b11de8389a091d2b7a38d6ecec4f7.png',

            ],
            [
            'name' =>'VIJAY NAGAR',
            'price' =>' 60Lac ',
            'description' =>' Bedrooms 2 Bathrooms 1Super area 5620 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'SURAT',
            'gallery' => 'https://teja8.kuikr.com//r1/20190529/ak_668_1700390711-1559105581_700x700.png',

            ],
            [
            'name' =>'TILAK NAGAR',
            'price' =>' 
            50Lac ',
            'description' =>'Bedrooms 5 Bathrooms 3Super area 4220 sqft Lift
Water pump
Solar heater
Swimming pool
Gymnasium
Open area
Joggers track
Playgrounds
Community hall
Amphitheatre and the list can be endless. ',
            'category' =>'JAIPUR',
            'gallery' => 'https://i.pinimg.com/originals/87/4b/11/874b11de8389a091d2b7a38d6ecec4f7.png',

            ],
                       

    	 ],
        );
    }
}
