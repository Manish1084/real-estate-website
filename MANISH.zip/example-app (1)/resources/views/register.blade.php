@extends('master')
@section("content")



<body id="body">

<div id="login-card" class="card">
<div class="card-body">
  <h2 class="text-center">Register form</h2>
  <br>
  <form action="register" method="POST" >
  @csrf()
    <div class="form-group">
      <input type="text" class="form-control" id="email" placeholder="Name" name="name" required="">
    </div>
    <div class="form-group">
      <input type="email" class="form-control" id="email" placeholder="Email" name="email"  required="">
    </div>
    <div class="form-group">
      <input type="password" class="form-control" id="email" placeholder="Password" name="password" required="">
    </div>
    <button type="submit" id="button" class="btn btn-primary deep-purple btn-block ">Login</button>
<br>
    <br>
 
  </form>
</div>
<div>
</div>
@endsection