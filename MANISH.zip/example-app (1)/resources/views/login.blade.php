

@extends ('master')
@section ("content")
<style>
  

</style>
<body id="body" style="background-color: pink">

<div id="login-card" class="card">
<div class="card-body">
  <h2 class="text-center">Login form</h2>
  <br>
  <form  method="POST" action="login">
  @csrf()
    <div class="form-group">
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required="">
    </div>
    <div class="form-group">
      <input type="password" class="form-control" id="email" placeholder="Enter password" name="pswd" required="">
    </div>
    <button type="submit" id="button" class="btn btn-primary deep-purple btn-block ">Login</button>
<br>
    <br>
 
  </form>
</div>
<div>


@endsection