<?php $__env->startSection("content"); ?>
<br>

<br>

<div id="myCarousel" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="https://www.sparkyjeans.com/assets/images/banner7.jpg" alt="Organic">
    </div>
    <div class="item">
      <img src="https://www.sparkyjeans.com/assets/images/banner5.jpg" alt="Organic">
    </div>
    <div class="item">
      <img src="https://fashfever.files.wordpress.com/2014/09/hm_denim001.jpeg" alt="Organic">
    </div>
  </div>
  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="wrap">

	<div id="columns" class="columns_4">
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <a href="detail/<?php echo e($item['id']); ?>"> <figure>
  <img src="<?php echo e($item['gallery']); ?>">
	<figcaption><h6><?php echo e($item['name']); ?></h6></figcaption>
    <span class="price">Rs<?php echo e($item->price); ?></span></a>
    <form action="/add_to_cart" method="POST">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="product_id" value=<?php echo e($item['id']); ?>>
           <button class="btn btn-success" >Add</></button>
           <button class="btn btn-danger" >Cart</></button>

            </form> 
   
	</figure>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akash/example-app/resources/views/product.blade.php ENDPATH**/ ?>