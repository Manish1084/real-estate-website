<?php $__env->startSection("content"); ?>
<style>
  

</style>
<body id="body" style="background-color: pink">

<div id="login-card" class="card">
<div class="card-body">
  <h2 class="text-center">Login form</h2>
  <br>
  <form  method="POST" action="login">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required="">
    </div>
    <div class="form-group">
      <input type="password" class="form-control" id="email" placeholder="Enter password" name="pswd" required="">
    </div>
    <button type="submit" id="button" class="btn btn-primary deep-purple btn-block ">Login</button>
<br>
    <br>
 
  </form>
</div>
<div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akash/example-app (1)/resources/views/login.blade.php ENDPATH**/ ?>